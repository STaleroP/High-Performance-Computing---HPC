/* parallel-002.c - Juan Sebastian Manrique Moreno
 * Cálculo de C como resta de matrices A y B más offset
 * Distribución de iteraciones en bloques de 5 elementos estáticos 
 * Paralelización de bucles anidados como uno solo
 */

#include <stdio.h>
#include <omp.h>

int main(){
    /* Se declaran las matrices y variables necesarias */
    int A[4][4]= { {0 , 1, 2, 3},{ 4, 5, 6, 7},{8, 9,10,11},{12,13,14,15} };
    int B[4][4]= { {15,14,13,12},{11,10, 9, 8},{7, 6, 5, 4},{ 3, 2, 1, 0} };
    int C[4][4]= { {},{},{},{} };
    int offset=33;
    int thisOffset=0;

    /* Se paralelizan ambos bucles como uno solo usando:
     * - Collapse(2) para fusionar los bucles
     * - Bloques estáticos de 5 elementos
     * - Copia privada inicial de offset
     * - Último valor de thisOffset preservado
     */
    #pragma omp parallel for collapse(2) schedule(static,5) firstprivate(offset) lastprivate(thisOffset)
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++){
            thisOffset = offset * (i*4 + j);  
            C[i][j] = A[i][j] - B[i][j] + thisOffset;
            printf("C[%d][%d]=%d, thisOffset=%d\n", i, j, C[i][j], thisOffset);
            
            int f = omp_get_thread_num();
            printf("i=%d,j=%d processed by thread=%d\n", i, j, f);
        }
    }

    printf("thisOffset=%d\n", thisOffset);
}