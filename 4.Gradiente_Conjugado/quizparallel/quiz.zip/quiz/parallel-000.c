/* parallel-000.c - Juan Sebastian Manrique Moreno
 * Vector C como suma de vectores A y B.
 * Variable total acumula valores usando reducción
 * Uso de directiva combinada para paralelizar bucle
 */

#include <stdio.h>
#include <omp.h>

int main(){
    /* Se obtiene el número de hilo maestro y se imprime */
    int m = omp_get_thread_num();
    printf("master thread=%d in serial region\n", m);
    
    /* Se declaran los vectores y la variable de reducción */
    int A[16]= {0 , 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15};
    int B[16]= {15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
    int C[16]= {};
    int total=0;

    /* Se paraleliza el bucle con:
     * - Reducción de la variable total
     * - Bloques estáticos de 3 elementos
     */
    #pragma omp parallel for reduction(+:total) schedule(static,3) 
    for(int i=0;i<16;i++){
        C[i] = A[i] + B[i];
        printf("C[%d]=%d\n", i, C[i]);
        total += C[i];

        int f = omp_get_thread_num();
        printf("i=%d processed by thread=%d\n", i, f);
    }

    printf("total=%d\n", total);
}