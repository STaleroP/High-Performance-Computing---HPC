/* parallel-001.c - Juan Sebastian Manrique Moreno
 * Cálculo de C como resta de vectores A y B más offset
 * Distribución de iteraciones en bloques de 5 elementos estáticos
 * Impresión del número de hilo por cada resultado
 */

#include <stdio.h>
#include <omp.h>

int main(){
    /* Se obtiene el número de hilo maestro y se imprime */
    int m = omp_get_thread_num();
    printf("master thread=%d in serial region\n", m);
    
    /* Se declaran los vectores y variables necesarias */
    int A[16]= {0 , 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15};
    int B[16]= {15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0};
    int C[16]= {};
    int offset=33;
    int thisOffset=0;

    /* Se paraleliza el bucle con:
     * - Bloques estáticos de 5 elementos
     * - Copia privada inicial de offset
     * - Último valor de thisOffset preservado
     */
    #pragma omp parallel for schedule(static,5) firstprivate(offset) lastprivate(thisOffset)
    for(int i=0;i<16;i++){
        thisOffset = offset * i;  
        C[i] = A[i] - B[i] + thisOffset;
        printf("C[%d]=%d, thisOffset=%d\n", i, C[i], thisOffset);

        int f = omp_get_thread_num();
        printf("i=%d processed by thread=%d\n", i, f);
    }

    printf("thisOffset=%d\n", thisOffset);
}